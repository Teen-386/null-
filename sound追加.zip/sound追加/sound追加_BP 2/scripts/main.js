import { world, ItemStack } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

// 登録されているサウンドの一覧データ（ID一覧の表示用）
const SOUND_LIST = [
  { id: "bgm.sougenwoyuku", name: "草原をゆく", type: "BGM" },
  { id: "bgm.karyunodoukutsu", name: "火竜の洞窟", type: "BGM" },
  { id: "bgm.neorock81", name: "君が見ていた世界の果て", type: "BGM" },
  { id: "bgm.moment", name: "Moment", type: "BGM" },
  { id: "bgm.yoimatsurinokaze", name: "宵祭りの風", type: "BGM" },
  { id: "se.cursor2", name: "カーソル移動2", type: "SE" },
  { id: "se.cursor5", name: "カーソル移動5", type: "SE" },
  { id: "se.magical02", name: "魔法効果音02", type: "SE" },
  { id: "se.magic_water14", name: "水魔法14", type: "SE" },
  { id: "se.magic_wind01", name: "風魔法01", type: "SE" },
  { id: "se.magic_water01", name: "水魔法01", type: "SE" },
  { id: "se.magic_thunder01", name: "雷魔法01", type: "SE" },
  { id: "se.magic_fire02", name: "炎魔法02", type: "SE" }
];

// 1. ワールド参加時の処理
world.afterEvents.playerSpawn.subscribe((event) => {
  if (event.initialSpawn) {
    const player = event.player;

    // 毎回（再ログイン時も・参加者全員に）チャット欄にクレジットを表示
    player.sendMessage("§e========================================");
    player.sendMessage("§b【使用BGM・効果音素材】");
    player.sendMessage("§f1. フリー音楽素材 H/MIX GALLERY 様 (https://hmix.net)");
    player.sendMessage("§f2. 魔王魂 様 (https://maou.audio)");
    player.sendMessage("§f3. 効果音ラボ 様 (https://soundeffect-lab.info)");
    player.sendMessage("§7※「メニュー」時計を使うと詳細とIDを確認できます");
    player.sendMessage("§e========================================");

    // ワールド全体で一番最初に入った1人（ワールド主）だけに1回だけ時計を渡す
    if (!world.getDynamicProperty("host_clock_given")) {
      const menuClock = new ItemStack("minecraft:clock", 1);
      menuClock.nameTag = "§eメニュー";

      const inventory = player.getComponent("minecraft:inventory").container;
      inventory.addItem(menuClock);

      world.setDynamicProperty("host_clock_given", true);
    }
  }
});

// 2. 「メニュー」という名前の時計を使った時だけメインメニューを開く
world.afterEvents.itemUse.subscribe((event) => {
  const item = event.itemStack;
  if (item.typeId === "minecraft:clock" && item.nameTag === "§eメニュー") {
    showMainMenu(event.source);
  }
});

// メインメニュー画面（再生・ストップボタンを削除）
function showMainMenu(player) {
  const form = new ActionFormData()
    .title("§lアドオン情報メニュー")
    .body("確認したい項目を選んでください。")
    .button("§bライセンス・クレジット表記")
    .button("§aサウンドID一覧");

  form.show(player).then((response) => {
    if (response.canceled) return;

    if (response.selection === 0) {
      showLicenseMenu(player);
    } else if (response.selection === 1) {
      showIdMenu(player);
    }
  });
}

// サブメニュー①：ライセンス表記画面
function showLicenseMenu(player) {
  const text = 
    "§e【使用BGM・効果音素材】§r\n\n" +
    "§b■ フリー音楽素材 H/MIX GALLERY 様§r\n" +
    "https://hmix.net\n\n" +
    "§b■ 魔王魂 様§r\n" +
    "https://maou.audio\n\n" +
    "§b■ 効果音ラボ 様§r\n" +
    "https://soundeffect-lab.info\n\n" +
    "§7※各素材の著作権は制作者様に帰属します。";

  const form = new ActionFormData()
    .title("§lライセンス・クレジット表記")
    .body(text)
    .button("§l戻る");

  form.show(player).then((response) => {
    if (!response.canceled) {
      showMainMenu(player);
    }
  });
}

// サブメニュー②：サウンドID一覧画面（テキスト表示のみ・再生機能なし）
function showIdMenu(player) {
  let bgmText = "§b■ BGM（音楽）§r\n";
  let seText = "\n§e■ SE（効果音）§r\n";

  // SOUND_LIST から自動でテキストを組み立てる
  for (const sound of SOUND_LIST) {
    if (sound.type === "BGM") {
      bgmText += `§a・${sound.id}§r（${sound.name}）\n`;
    } else {
      seText += `§a・${sound.id}§r（${sound.name}）\n`;
    }
  }

  const fullText = 
    "§e【登録済みサウンドID一覧】§r\n" +
    "コマンド（/playsound）で再生できます。\n\n" +
    bgmText +
    seText;

  const form = new ActionFormData()
    .title("§lサウンドID一覧")
    .body(fullText)
    .button("§l戻る");

  form.show(player).then((response) => {
    if (!response.canceled) {
      showMainMenu(player);
    }
  });
}
